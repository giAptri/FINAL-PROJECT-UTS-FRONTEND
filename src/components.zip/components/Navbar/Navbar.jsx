import styles from './Navbar.module.css';


export default function Navbar () {
  return (
    <div className={styles.container}>
      <a href="/">Covid id</a>
      <nav>
        <ul>
            <li><a href="">Global</a></li>
            <li><a href="">Indonesia</a></li>
            <li><a href="">Provinsi</a></li>
            <li><a href="">About</a></li>
        </ul>
      </nav>
    </div>
  )
}