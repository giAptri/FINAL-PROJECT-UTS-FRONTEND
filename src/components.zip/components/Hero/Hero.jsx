import styles from './Hero.module.css';


export default function Hero () {
  return (
    <div className={styles.container}>
      <div>
        <h1>Covid ID</h1>
        <p>Monitoring Perkembangan Covid</p>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Rem autem dolor vitae harum numquam modi rerum veritatis unde incidunt exercitationem alias eos adipisci, consequatur ea quo! Officia tempore fugit illum.</p>
        <button>vaccine</button>
      </div>
      <div>
        <img src="/img/hero.svg" alt="" />
      </div>
    </div>
  )
}