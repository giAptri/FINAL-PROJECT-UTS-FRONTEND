import styles from './Province.module.css';


export default function Province () {
  return (
    <div className={styles.container}>
      Province
    </div>
  )
}